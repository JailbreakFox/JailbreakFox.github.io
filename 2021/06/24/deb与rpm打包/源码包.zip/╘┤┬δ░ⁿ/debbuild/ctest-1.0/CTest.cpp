#include <iostream>
#include <string>

int main()
{
	std::cout << "It works" << std::endl;

	std::string str;

	std::cin >> str;

    return 0;
}
