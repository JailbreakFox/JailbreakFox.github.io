
	bool found = isFound();
	if ( found )
	{
		// strip any trailing SEPCHAR
		if ( strFile[strFile.size()-1] == SEPCHAR )
			request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
		else
			request.setFullPath( strFile );

		// if it's a folder, see if we can redirect to one of the default docs or apps
		if ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY )
		{
			// check for existence of a default doc or app
			if ( !checkDefault( request, IDS_DEFAULTDOC, false ) )
				checkDefault( request, IDS_DEFAULTAPP, true );
		}
		else if ( request.getExecute() && !isSeverApp(request) )
		{
			request.addError( idHttpBadRequest );
		}
	}
	else
	{
		request.addError( idHttpNotFound );
	}
	
	return found;
