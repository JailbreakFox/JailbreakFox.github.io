
BOOL CSTMCrossEventHandle::CanCrossMove()
{	
	BOOL ret=TRUE;
	if(m_pDoc->m_arrSel.GetSize()!=1)
		ret=FALSE;
	else 
	{
		ELEINFO ei=m_pDoc->m_arrSel.GetAt(0);
		if(ei.eleType!=ET_CROSS||ei.index==-1)
			ret=FALSE;
	}
	return ret;
}
