public void testGetIntPart() throws Exception {
  assertEquals("0", digitTransform.getIntPart("0.01");
  assertEquals("1", digitTransform.getIntPart("1.2");
  assertEquals("1234", digitTransform.getIntPart("1234");
  assertEquals("1", digitTransform.getIntPart("1.01");
  assertEquals("0", digitTransform.getIntPart("0.01");
  assertEquals("11111", digitTransform.getIntPart("11111");
  assertEquals("1000", digitTransform.getIntPart("1000.11");
}
