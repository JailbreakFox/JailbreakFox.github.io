
//
//���� 5
//
  else if ((modifiers & (IM_CTRL_MASK | IM_ALT_MASK |
 IM_SUPER_MASK | IM_RELEASE_MASK)) == 0) 
  {
      if ((keyvalue >= '0' && keyvalue <= '9') &&
         (m_candiWindowSize >= 10 || keyvalue < ('1' + m_candiWindowSize))) // try to make selection
      { 
          if (!m_pIC->isEmpty ()) 
          {
              changeMasks |= KEYEVENT_USED;
              unsigned sel = (keyvalue == '0'? 9: keyvalue-'1');
              _makeSelection (sel, changeMasks);
          }
          else
          {
              m_numeric_mode = true;
          }
          m_pHotkeyProfile->rememberLastKey(key);
      } 
      else if (keyvalue == '.' && m_numeric_mode) 
      {
          m_numeric_mode = false;
          m_pHotkeyProfile->rememberLastKey(key);
      }
      else 
      {
          m_numeric_mode = false;
          _eventProcessHelper(changeMasks,keycode, keyvalue, modifiers);
      }
   }   
      
