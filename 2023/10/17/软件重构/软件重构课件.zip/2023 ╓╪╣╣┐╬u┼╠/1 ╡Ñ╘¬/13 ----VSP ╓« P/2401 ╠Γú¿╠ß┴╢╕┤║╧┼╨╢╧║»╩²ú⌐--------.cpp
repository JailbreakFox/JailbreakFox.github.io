�� 2401 �⣺

//������Դ��VC++���ӵ�ͼ���ƹ���
void CSTMBSEventHandle::OnLButtonUp(UINT nFlags, CPoint point)
{
	POINT	originpoint;
	originpoint=m_pMapView->GetScrollPosition();
	point.Offset(originpoint);
	if(m_pDoc->m_focusEI.eleType==ET_PATH)	//destinate type
	{
		if(m_pDoc->m_focusEI.index!=-1)
		{
			if(m_pDoc->m_activeType==ACT_BS_PICK)//add a bus station
			{
				BSINFO	bsi;
				bsi.path_id=m_pDoc->m_focusEI.index;
				bsi.pos=point;
				CBSNameInputDlg inputdlg;
				if(inputdlg.DoModal()==IDOK)
				{
					strcpy(bsi.name,inputdlg.m_BSName);
					int index=m_pDoc->AddBS(bsi);
					DrawBS(index);
				}
			}
		}
	}else if(m_pDoc->m_focusEI.eleType==ET_BS)//self type
	{
		if(m_pDoc->m_focusEI.index!=-1)
		{	
			if(m_pDoc->m_activeType==ACT_BROWSE)//browse select the bus station
			{
				CString msg;
				BSINFO	bsi=m_pDoc->m_arrBS.GetAt(m_pDoc->m_focusEI.index);
				msg.Format("you clicked a bus station! name=%s,pos:x=%d;y=%d",
						bsi.name,bsi.pos.x,bsi.pos.y);
			}
		}
	}
	if(m_pDoc->m_activeType==ACT_BS_MOVE)//move finish
	{	
		m_pDoc->m_activeType=ACT_BS_PICK; //wait to fill
	}
}
