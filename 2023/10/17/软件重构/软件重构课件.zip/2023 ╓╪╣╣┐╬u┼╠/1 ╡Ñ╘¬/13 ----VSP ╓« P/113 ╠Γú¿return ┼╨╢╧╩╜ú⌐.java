


////////////// �� 1

if ( flag == 1 ){
    return true;
}
else{
    return false;
}



////////////// �� 2

if ( "Male".equals(gender) ) {
    return "Mr.";
}
else{
    return "Mrs.";
}


