


=================== ��1��

int getTaskCount����
{	
	int count = 0;
	if(taskList != null && !taskList.isEmpty()){
	
	  //skip...
	
	  return count;
	}
	else {
	  return count;
	}
}



=================== ��2��

public boolean contain(int year, Month month, int day) {
  boolean found = false;
  for (IPolyDate date : dateList) {
    if (date.same(year, month.getMonth(), day)) {
      found = true;
      break;
    }
  }

  return found;
}
