
    TETPSProtectMgrIF* pTPSMgrIF;

    if(TE_SUCCEED == VAGetIF(pTPSMgrIF, TETPSProtectMgrIF, pNE, NULL ) )
    {

            TPSAllGroups  allGroup;


            TEERRORCODE  TpsRet = pTPSMgrIF->GetAllGroups(ulNeID, allGroup);
            if(TpsRet == TE_SUCCEED)
            {
                pTPSMgrIF->FilterEnabledTPSProtect(allGroup, pNE); 
                int i = 0;
                for(; i < allGroup.Count() ; ++i)
                {
                    TpsRet = pTPSMgrIF->QueryState(ulNeID, allGroup[i]);
                    if (TpsRet != TE_SUCCEED)
                    {
                        SDH_TRACE(DEBUG_LEVEL_EXTERROR, "Err when Get tpspg state from ne, neid = %d \n", ulNeID);
                        break;
                    }
                }
            }
            
            
            if( TpsRet == TE_SUCCEED  )
            {
                TECPState cpstate;
                for (int i = 0; i < allGroup.Count() ; i++)
                {
                    cpstate.m_SlotID = ( isSwitched( ) ) ? allGroup[i].m_WorkUnitList[j].m_WorkSlot : allGroup[i].m_ProtectSlot;
                    cpstate.m_eWorkState = CPWS_STANDBY;
                    for ( std::vector<TECPState>::iterator iter = pWorkStateList->begin(); iter != pWorkStateList->end(); ++iter )
                    {
                        if ((*iter).m_SlotID == cpstate.m_SlotID)
                        {
                            (*iter).m_eWorkState = cpstate.m_eWorkState;
                        }
                    }
            
                    pWorkStateList->push_back(cpstate);
                }
            }

    
    }

