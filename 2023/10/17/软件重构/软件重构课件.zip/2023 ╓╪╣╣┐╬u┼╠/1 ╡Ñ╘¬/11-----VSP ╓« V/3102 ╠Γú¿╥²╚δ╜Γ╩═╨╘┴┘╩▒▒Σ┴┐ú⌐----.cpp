
public boolean tailGreatHead(int headHour, int headMinute, int tailHour,
			int tailMinute, boolean includeEqual) {

  return ((headHour < tailHour) ||
 ((headHour == tailHour) &&
           ((headMinute < tailMinute) || includeEqual && (headMinute == tailMinute))));
}
