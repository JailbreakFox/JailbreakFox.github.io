
/////////listrectangle.c---�ع��ַ�������struct 

#include "rectangle.h"

typedef struct lnode *ListPtr;

typedef struct lnode {
	Rectangle rect;
	ListPtr previous;
	ListPtr next;
} ListNode;

typedef struct { ///////////////////////// here
	ListPtr head;
	ListPtr last;
	int numElems;
} ListOfRectangles;

ListOfRectangles list;

void insert(Rectangle r) {
	ListNode n;
	n.rect = r;
	n.previous = n.next = NULL;
	
	if (list.head == NULL) {
		list.head = list.last = &n;
	}
	else {
		ListPtr current = list.head;
		
		while (current != NULL &&
		less_than(current->rect.upper_left, n.rect.upper_left)) {
			current = current->next;
		}
		
		if (current == list.head) {
			n.next = list.head;
			list.head->previous = &n;
			list.head = &n;
		}
		else if (current == NULL) {
			n.previous = list.last;
			list.last->next = &n;
			list.last = &n;
		}
		else {
			n.previous = current->previous;
			current->previous->next = &n;
			n.next = current;
			current->previous = &n;
		}
	}
	list.numElems += 1;
}

