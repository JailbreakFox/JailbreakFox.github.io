
public boolean tailGreatHead(int headHour, int headMinute, int tailHour,
			int tailMinute, boolean includeEqual) {

  return ((headHour < tailHour) ||
 ((headHour == tailHour) &&
           ((headMinute < tailMinute) || includeEqual && (headMinute == tailMinute))));
}




///////////////////////// 答案
//手法：引入解释性临时变量，提高程序可理解性


public boolean tailGreatHead(int headHour, int headMinute, int tailHour,
			int tailMinute, boolean includeEqual) {
  boolean tailGreatHeadHour = (headHour < tailHour);
  boolean tailEqualHeadHour = (headHour == tailHour);
  boolean tailGreatHeadMinute = (headMinute < tailMinute);
  boolean tailEqualHeadMinute = (headMinute == tailMinute);

  boolean tailGreatEqualHeadMinute = tailGreatHeadMinute || includeEqual
				&& tailEqualHeadMinute;

  return (tailGreatHeadHour || (tailEqualHeadHour && tailGreatEqualHeadMinute));
}
