
Ҫ�㣺
//Ϊ����ߴ���ɶ��ԡ���
//ҲΪ�˽������һ��Ĵ������Ϊ�����ع����̵�
//�����һ��������ͬʱ���ڶ�����ͼ
//��������� split �ɶ���������ֱ��ʶһ��ר�е���;



���������ߣ�����



////////////////////////////////////////// new code




    TETPSProtectMgrIF* pTPSMgrIF;

    if(TE_SUCCEED == VAGetIF(pTPSMgrIF, TETPSProtectMgrIF, pNE, NULL ) )
    {

            TPSAllGroups  allGroup;

            //
            // TpsRet��ʧ�ˣ���split�� �������� ��
            //
            TEERRORCODE  canGetAllGroups = pTPSMgrIF->GetAllGroups(ulNeID, allGroup);
            TEERRORCODE  isAnyGroupError = TE_SUCCEED;



            if( canGetAllGroups == TE_SUCCEED)////////////////////����canGetAllGroups
            {
                pTPSMgrIF->FilterEnabledTPSProtect(allGroup, pNE);
                for(int i = 0; i < allGroup.Count() ; ++i)
                {
                    isAnyGroupError = pTPSMgrIF->QueryState(ulNeID, allGroup[i]);
                    if (isAnyGroupError != TE_SUCCEED)//////////////////// ����isAnyGroupError
                    {
                        SDH_TRACE(DEBUG_LEVEL_EXTERROR, "Err when Get tpspg state from ne, neid = %d \n", ulNeID);
                        break;
                    }
                }
            }
            

            //
            //�������д���ʱ��������ȷ������ͣ��
            //
            if(  (canGetAllGroups == TE_SUCCEED) && ( isAnyGroupError == TE_SUCCEED ) )
            {
                TECPState cpstate;
                for (int i = 0; i < allGroup.Count() ; i++)
                {
                    cpstate.m_SlotID = ( isSwitched( ) ) ? allGroup[i].m_WorkUnitList[j].m_WorkSlot : allGroup[i].m_ProtectSlot;
                    cpstate.m_eWorkState = CPWS_STANDBY;
                    for ( std::vector<TECPState>::iterator iter = pWorkStateList->begin(); iter != pWorkStateList->end(); ++iter )
                    {
                        if ((*iter).m_SlotID == cpstate.m_SlotID)
                        {
                            (*iter).m_eWorkState = cpstate.m_eWorkState;
                        }
                    }
            
                    pWorkStateList->push_back(cpstate);
                }
            }

        
    }




////////////////////////////////////////// old code



    TETPSProtectMgrIF* pTPSMgrIF;

    if(TE_SUCCEED == VAGetIF(pTPSMgrIF, TETPSProtectMgrIF, pNE, NULL ) )
    {

            TPSAllGroups  allGroup;

            //
            //���Ǳ����ĵ�һ����;
            //
            TEERRORCODE  TpsRet = pTPSMgrIF->GetAllGroups(ulNeID, allGroup/*, NOT_LOCK*/); //lint !e613
            if(TpsRet == TE_SUCCEED)
            {
                pTPSMgrIF->FilterEnabledTPSProtect(allGroup, pNE); //lint !e613
                int i = 0;
                for(; i < allGroup.Count() ; ++i)
                {



                    //
                    //���Ǳ����ĵڶ�����;
                    //
                    TpsRet = pTPSMgrIF->QueryState(ulNeID, allGroup[i]); //lint !e613
                    if (TpsRet != TE_SUCCEED)
                    {
                        SDH_TRACE(DEBUG_LEVEL_EXTERROR, "Err when Get tpspg state from ne, neid = %d \n", ulNeID);
                        break;
                    }
                }
            }
            
            
            
            
            //
            //�������ͬ�£��������д���ʱ����ʼ���Լ� ��ѧ ûѧ�� (^o^)
            //
            if( TpsRet == TE_SUCCEED  )
            {
                TECPState cpstate;
                for (int i = 0; i < allGroup.Count() ; i++)
                {
                    cpstate.m_SlotID = ( isSwitched( ) ) ? allGroup[i].m_WorkUnitList[j].m_WorkSlot : allGroup[i].m_ProtectSlot;
                    cpstate.m_eWorkState = CPWS_STANDBY;
                    for ( std::vector<TECPState>::iterator iter = pWorkStateList->begin(); iter != pWorkStateList->end(); ++iter )
                    {
                        if ((*iter).m_SlotID == cpstate.m_SlotID)
                        {
                            (*iter).m_eWorkState = cpstate.m_eWorkState;
                        }
                    }
            
                    pWorkStateList->push_back(cpstate);
                }
            }

    
    }









