

#include "rectangle.h"

typedef struct lnode *ListPtr;

typedef struct lnode {
	Rectangle rect;
	ListPtr previous;
	ListPtr next;
} ListNode;

ListPtr head;

ListPtr last;

int numElems;

void insert(Rectangle r) {
	ListNode n;
	n.rect = r;
	n.previous = n.next = NULL;
	
	if (head == NULL) {
		head = last = &n;
	}
	else {
		ListPtr current = head;
		
		while (current != NULL &&
		less_than(current->rect.upper_left, n.rect.upper_left)) {
			current = current->next;
		}
		
		if (current == head) {
			n.next = head;
			head->previous = &n;
			head = &n;
		}
		else if (current == NULL) {
			n.previous = last;
			last->next = &n;
			last = &n;
		}
		else {
			n.previous = current->previous;
			current->previous->next = &n;
			n.next = current;
			current->previous = &n;
		}
	}
	numElems += 1;
}

