

public IPolyDate getIndexWeekDay(Month month, int index, WeekDay weekDay) {

  int count = this.countWeekDay(month, weekDay);
  if (index > count) {
	throw new ExceedMaxWeekIndexOfMonthException("Arguement index[" + 
	index + "] exceeds max week index[" + 
	count + "] of month[" + month.toString() + "].");
  }

  count = 0;
  int[][] weeks = this.getDates()[month.getMonth()];
  for (int week = 0, weekLen = weeks.length; week < weekLen; week++) {
    int date = weeks[week][weekDay.getDay()];
    if (date > 0) {
      if (++count == index) {
        return new PolyDate(year, month.getMonth(), date);
      }
    }
  }

  return null;
}
