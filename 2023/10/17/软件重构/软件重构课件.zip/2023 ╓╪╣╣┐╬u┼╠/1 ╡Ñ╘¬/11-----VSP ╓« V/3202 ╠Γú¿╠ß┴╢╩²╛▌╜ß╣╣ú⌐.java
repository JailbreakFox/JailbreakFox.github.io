



//////////////// �� 1



void PrintStudent(int id, string name, int age, int score)
{
	......
}




//////////////// �� 2



public void Create(decimal amount, Student student, 
IEnumerable<Course> courses, decimal credits)
{
	// do work
}



//////////////// �� 3


public int getRemainMinutes(int hour, int minute, 
                         int fromHour, int fromMinute
                         int toHour, int toMinute) {
  // --------from-------to--------position-------
  int startHour = toHour;
  int startMinute = toMinute;
  
  if (this.fromAfterEqual(hour, minute)) {
    // ------position------from-------to--------
    startHour = fromHour;
    startMinute = fromMinute;
  } else if (this.toAfterEqual(hour, minute)) {
    // ------from-------position------to--------
    startHour = hour;
    startMinute = minute;
  }

  return this.getMinutes(startHour, startMinute, toHour, toMinute);
}


