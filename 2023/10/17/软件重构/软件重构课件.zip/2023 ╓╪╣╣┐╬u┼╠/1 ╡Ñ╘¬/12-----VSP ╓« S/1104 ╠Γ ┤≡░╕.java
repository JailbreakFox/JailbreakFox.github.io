
	//
	// ���� 2 �ж�found
	//
	bool found = false;
	string strExtra; // extra path info

	request.setAttributes( GetFileAttributes( strFile.c_str() ) );

	if ( request.getAttributes() != -1 )
		found = true;
	else
		found = makeExtraPath(request, strFile, strExtra );

	if ( ! found )
	{
		request.addError( idHttpNotFound );
		return false;
	}
	
	//
	// ���� 3 ���� FullPath
	//
	// strip any trailing SEPCHAR
	if ( strFile[strFile.size()-1] == SEPCHAR )
		request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
	else
		request.setFullPath( strFile );

	// see if we need to set the extra path info
	if ( !strExtra.empty() )
	{
		request.setPathInfo( strExtra );

		if ( urlToPath( strExtra ) )
			request.setPathTranslated( strExtra );
	}



/////////////////////////////////////////////////////////////// ��
//���������飩����ʾ����strExtra��request���б������÷�����


	//
	// ���� 2������ PathInfo 
	//
	bool found = false;
	string strExtra; // extra path info

	request.setAttributes( GetFileAttributes( strFile.c_str() ) );

	if ( request.getAttributes() != -1 )
		found = true;
	else
		found = makeExtraPath(request, strFile, strExtra );
	
	if ( ! found )
	{
		request.addError( idHttpNotFound );
		return false;
	}

	if ( !strExtra.empty() )// �˶δ��룬�������˴���
	{
		request.setPathInfo( strExtra );

		if ( urlToPath( strExtra ) )
			request.setPathTranslated( strExtra );
	}


	//
	// ���� 3������ FullPath
	//
	if ( strFile[strFile.size()-1] == SEPCHAR )
		request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
	else
		request.setFullPath( strFile );

