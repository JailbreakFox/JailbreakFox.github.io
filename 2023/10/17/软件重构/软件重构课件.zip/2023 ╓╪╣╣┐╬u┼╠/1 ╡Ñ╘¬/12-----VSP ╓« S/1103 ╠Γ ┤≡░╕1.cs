public class Receipt
{
	private IList<decimal> Discounts { get; set; }
	
	private IList<decimal> ItemTotals { get; set; }
	
	public decimal CalculateGrandTotal()
	{
		decimal subTotal = 0m;
		foreach (decimal itemTotal in ItemTotals)
			subTotal += itemTotal;
		if (Discounts.Count > 0)
		{
			foreach (decimal discount in Discounts)
				subTotal -= discount;
		}
		decimal tax = subTotal * 0.065m;
		subTotal += tax;
		return subTotal;
	}
}




///////////////////////////////////////////////////////// 答案
//很多时候，提炼函数被滥用。将语句分成 语句块如何？



		//
		// step 1 : 累加
		//
		decimal subTotal = 0m;
		foreach (decimal itemTotal in ItemTotals)
			subTotal += itemTotal;

		//
		// step 2 : 打折
		//
		if (Discounts.Count > 0)
		{
			foreach (decimal discount in Discounts)
				subTotal -= discount;
		}

		//
		// step 3 : 缴税
		//
		decimal tax = subTotal * 0.065m;
		subTotal += tax;
		return subTotal;


