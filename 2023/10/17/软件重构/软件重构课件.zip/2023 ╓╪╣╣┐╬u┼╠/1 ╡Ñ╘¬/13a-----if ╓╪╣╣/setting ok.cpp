static void pmRunSystem(bool enable)
{
	//
	// 0
	//
  if(!enable)
  {
    //Disable UART
    nrf_gpio_cfg_input(UART_TX_PIN, NRF_GPIO_PIN_PULLDOWN);
    //Hold reset
    nrf_gpio_pin_clear(STM_NRST_PIN);
	
    return;
  }
  

	//
	// 1
	//

  // Release the reset pin!
  nrf_gpio_pin_set(STM_NRST_PIN);
  //Activate UART TX pin
  nrf_gpio_cfg_output(UART_TX_PIN);
  nrf_gpio_pin_set(UART_TX_PIN);
  
  
  
 	//
	// 2
	//
#ifdef HAS_TI_CHARGER
  nrf_gpio_cfg_output(PM_EN1);
  nrf_gpio_cfg_output(PM_EN2);
  // Set 500mA current
  nrf_gpio_pin_set(PM_EN1);
  nrf_gpio_pin_clear(PM_EN2);
  // Enable charging
  nrf_gpio_cfg_output(PM_CHG_EN);
  nrf_gpio_pin_clear(PM_CHG_EN);
#endif
  
  
  
	//
	// 3 Enable RF power amplifier
	//
  nrf_gpio_cfg_output(RADIO_PAEN_PIN); 
  
  
	//
	// 4
	//
#ifdef DISABLE_PA
  nrf_gpio_pin_clear(RADIO_PAEN_PIN);
#else
  nrf_gpio_pin_set(RADIO_PAEN_PIN);
#endif
 
 
	//
	// 5
	//
#ifdef HAS_BAT_SINK
  // Sink battery divider
  nrf_gpio_cfg_output(PM_VBAT_SINK_PIN);
  nrf_gpio_pin_clear(PM_VBAT_SINK_PIN);
#endif


	//
	// 6
	//
  pmStartAdc(adcVBAT);
}