// config set data is a long string of blocks with the following structure:
// [bank] [offset] [length] [byte[0], byte[1], ..., byte[length]]
uint8_t MPU6050_writeDMPConfigurationSet(const uint8_t *data,uint16_t dataSize,uint8_t useProgMem)
{
  uint8_t *progBuffer,success,special;
  uint16_t i;
  uint8_t bank,offset,length;
  
  for(i=0;i<dataSize;)
  {
    bank=data[i++];
    offset=data[i++];
    length=data[i++];
	
    if(length>0)
    {
      progBuffer=(uint8_t*)data+i;
      success=MPU6050_writeMemoryBlock(progBuffer,length,bank,offset,1,0);
      i+=length;
    }
    else
    {
      special=data[i++];
      if(special==0x01)
      {
        success=IICwriteByte(devAddr,MPU6050_RA_INT_ENABLE,0x32);
      }
      else
      {
        success=0;
      }	
    }
  
    if(!success)
    {
      return 0;
    }
  }
  return 1;
}
