
void FlightModeFSMSimple(void)
{
    if(FLY_ENABLE)
    {
        if(RC_DATA.THROTTLE>=600 )
        {
            if(altCtrlMode!=CLIMB_RATE)
            {
                zIntReset=1;
                thrustZSp=0;
                altCtrlMode=CLIMB_RATE;
                offLandFlag=1;
                altLand=-nav.z;
                SetHeadFree(1);
            }
        }
        else
        {
            if(altCtrlMode==MANUAL)
            {
                RC_DATA.THROTTLE=SLOW_THRO;
            }
        }

    }
}
