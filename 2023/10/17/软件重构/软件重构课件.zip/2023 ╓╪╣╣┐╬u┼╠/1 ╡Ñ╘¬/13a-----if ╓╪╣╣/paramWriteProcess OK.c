static void paramWriteProcess(int ident, void* valptr)
{
  int id=variableGetIndex(ident);
  
  if(id<0) 
  {
    p.data[0]=-1;
    p.data[1]=ident;
    p.data[2]=ENOENT;
    p.size=3;
    
    crtpSendPacket(&p);
    return;
  }
  
  if(params[id].type&PARAM_RONLY)
    return;
  
  switch(params[id].type&PARAM_BYTES_MASK)
  {
    case PARAM_1BYTE:
      *(uint8_t*)params[id].address=*(uint8_t*)valptr;
      break;
    case PARAM_2BYTES:
      *(uint16_t*)params[id].address=*(uint16_t*)valptr;
      break;
    case PARAM_4BYTES:
      *(uint32_t*)params[id].address=*(uint32_t*)valptr;
      break;
    case PARAM_8BYTES:
      *(uint64_t*)params[id].address=*(uint64_t*)valptr;
      break;
  }
  
  crtpSendPacket(&p);
}