//����ص�ѹ
void BatteryCheck(void)
{
  Battery.BatteryAD=GetBatteryAD();//��ص�ѹ���
  Battery.BatteryVal=Battery.Bat_K*(Battery.BatteryAD/4096.0)*Battery.ADRef;
  if(FLY_ENABLE)
  {
    if(Battery.BatteryAD<=Battery.BatteryADmin)
    {
      Battery.alarm=1;
    }
    else
      Battery.alarm=0;
  }
  else
  {
    //����3.7v�Ҵ��ڳ�����ѹBAT_CHG_VAL
    if((Battery.BatteryVal<BAT_ALARM_VAL)&&(Battery.BatteryVal>BAT_CHG_VAL))
      Battery.alarm=1;
    else
      Battery.alarm=0;
  }
  
  if(Battery.BatteryVal<BAT_CHG_VAL)//on charge
  {
    Battery.chargeSta=1;
    BT_off();
  }
  else
    Battery.chargeSta=0;
}
