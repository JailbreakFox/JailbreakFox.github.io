// config set data is a long string of blocks with the following structure:
// [bank] [offset] [length] [byte[0], byte[1], ..., byte[length]]
uint8_t MPU6050_writeDMPConfigurationSet(
const uint8_t *data, uint16_t dataSize, uint8_t useProgMem) 
{
  uint8_t bank,offset,length,firstByteOfBody;
  uint8_t *body;
  uint8_t success;
  
  for(uint16_t i=0;i<dataSize;) 
  {
    bank=data[i];
    offset=data[i+1];
    length=data[i+2];
    firstByteOfBody = data[i+3];
    body=data+i+3;
    
    if(length>0)
    {
      success=MPU6050_writeMemoryBlock(body,length,bank,offset,1,0);
      i=i+3+length;
    }
    else if(firstByteOfBody==0x01)
    {
      success=IICwriteByte(devAddr,MPU6050_RA_INT_ENABLE,0x32);
      i=i+3+1;
    }
    else
    {
      success=0;
    }

  
    if (!success) 
    {
      return 0;
    }
  }
  return 1;
}
