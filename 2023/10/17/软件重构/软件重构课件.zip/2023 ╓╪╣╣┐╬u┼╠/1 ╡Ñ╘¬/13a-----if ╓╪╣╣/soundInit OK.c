void soundInit(void)
{
  if(isInit)
  {
    return;
  }
  
  neffect=sizeof(effects)/sizeof(effects[0])-1;
  
  timer=xTimerCreate("SoundTimer",M2T(10),pdTRUE,NULL,soundTimer);
  xTimerStart(timer, 100);
  
  isInit=true;
}