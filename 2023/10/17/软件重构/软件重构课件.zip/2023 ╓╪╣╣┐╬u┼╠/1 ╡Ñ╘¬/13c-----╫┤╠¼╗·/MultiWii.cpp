#define MAX_LEN 32
volatile uint8_t UdataBuf[MAX_LEN];
uint8_t bufP=0;
uint8_t appCmdFlag;
uint32_t lastGetStickTime;
uint32_t lastGetAppTime;
uint8_t flyLogApp;

static uint8_t validDataLen=0;
static uint8_t checksum=0;

void CommApp(uint8_t ch)
{
  UdataBuf[bufP]=ch;
  
  if(bufP<3)
  {
    switch(bufP)
    {
      case 0:
        if(UdataBuf[bufP]=='$')
          bufP++;
        break;
      case 1:
        if(UdataBuf[bufP]=='M')
          bufP++;
        else
          bufP=0;
        break;
      case 2:
        if(UdataBuf[bufP]=='<')
          bufP++;
        else
          bufP=0;
        break;
    }
  }
  else	//valid data
  {
    if(bufP==3)	//len
    {
      checksum=0;
      validDataLen=UdataBuf[bufP];
    }
  
    if(bufP==4)	//cmd
    {
      appCmdFlag=UdataBuf[bufP];
    }
  
    bufP++;
  
    if(bufP>=validDataLen+6)	//len֮��$ M < len cmd chk�����ֽ�δ����
    {
      //chksum
      if(UdataBuf[bufP-1]==checksum)
      {
        if(appCmdFlag==MSP_FLY_STATE)
        {
          flyLogApp=1;
        }
        if(stickOrAppControl!=STICK_CTRL)
        {
          CommAppCmdProcess();
          stickOrAppControl=APP_CTRL;
        }
        btSrc=SRC_APP;
        lastGetAppTime=millis();		//ms
      }
      bufP=0;
    }
    else
      checksum^=UdataBuf[bufP-1];
  }
}