#define MAX_LEN 32
volatile uint8_t UdataBuf[MAX_LEN];
uint8_t bufP=0;
uint8_t appCmdFlag;
uint32_t lastGetStickTime;
uint32_t lastGetAppTime;
uint8_t flyLogApp;

static uint8_t validDataLen=0;
static uint8_t checksum=0;
static uint8_t packetHeader[]={'$','M','<'};

void CommApp(uint8_t ch)
{
  //
  UdataBuf[bufP]=ch;
  
  //
  //packet header
  //
  if(bufP<3)
  {
    if(ch==packetHeader[bufP])
      bufP++;
    else
      bufP=0;
    
    return;
  }

  //
  //len
  //
  if(bufP==3)
  {
    checksum=0;
    validDataLen=ch;
  }

  //
  //cmd
  //
  if(bufP==4)
  {
    appCmdFlag=UdataBuf[bufP];
  }

  //
  //checksum
  //
  bufP++;		
  if(bufP<validDataLen+6)	//len֮�� $ M < len cmd chk�����ֽ�δ����
  {
    checksum^=ch;
  }
  else//packet complete, this ch contain checksum
  {
    if(ch==checksum)
    {
      if(appCmdFlag==MSP_FLY_STATE)
      {
        flyLogApp=1;
      }
      if(stickOrAppControl!=STICK_CTRL)
      {
        CommAppCmdProcess();
        stickOrAppControl=APP_CTRL;
      }
      btSrc=SRC_APP;
      lastGetAppTime=millis();
    }
    bufP=0;
  }
}