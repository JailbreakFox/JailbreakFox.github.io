typedef enum
{
  waitForFirstStart,
  waitForSecondStart,
  waitForDirection,
  waitForLength,
  waitForCmd,
  waitForData,
  waitForChksum
} RxState;

#define MAX_LEN 32
volatile uint8_t UdataBuf[MAX_LEN];
uint8_t bufP=0;
uint8_t appCmdFlag;
uint32_t lastGetStickTime;
uint32_t lastGetAppTime;
uint8_t flyLogApp;

static uint8_t validDataLen=0;
static uint8_t checksum=0;
RxState rxState=waitForFirstStart;
  
void CommApp(uint8_t ch)
{
  switch(rxState)
  {
    case waitForFirstStart:
      rxState=(ch=='$')?waitForSecondStart:waitForFirstStart;
      break;
    case waitForSecondStart:
      rxState=(ch=='M')?waitForDirection:waitForFirstStart;
      break;
    case waitForDirection:
      rxState=(ch=='<')?waitForLength:waitForFirstStart;
      break;
    case waitForLength:
      validDataLen=ch;
      checksum=0;
      checksum^=ch;
      rxState=waitForCmd;
      break;
    case waitForCmd:
      appCmdFlag=ch;
      checksum^=ch;
      rxState=(validDataLen>0)?waitForData:waitForChksum;
      break;
    case waitForData:
      UdataBuf[bufP]=ch;
      bufP++;		
      checksum^=ch;
      if(bufP==validDataLen)
      {
        rxState=waitForChksum;
      }
      break;
    case waitForChksum:
      if(ch==checksum)
      {
        if(appCmdFlag==MSP_FLY_STATE)
        {
          flyLogApp=1;
        }
        if(stickOrAppControl!=STICK_CTRL)
        {
          CommAppCmdProcess();
          stickOrAppControl=APP_CTRL;
        }
        btSrc=SRC_APP;
        lastGetAppTime=millis();
      }
      bufP=0;
      rxState=waitForFirstStart;
      break;
    default:
      ASSERT(0);
      break;
  }
}