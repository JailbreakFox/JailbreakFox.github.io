
// ���ϡ�����ְ���������Ь��ʶ������

// ��˫��Ь��	�������÷���������ְ�������ִ��·������



bool HttpServerInfo::find ( HttpRequest & request, 
						    string & strFile )
{

	strFile = request.getUrl();// get url


	//
	// ���� 1 
	//
	StringUtil::trimLeft( strFile, "/" );// remove leading indicators
	
	if ( ! urlToPath( strFile ) )// change from URL to local file system path
	{
		request.addError( idHttpBadRequest );
		return false;
	}



	//
	// ���� 2 
	//
	bool found = false;
	string strExtra; // extra path info

	request.setAttributes( GetFileAttributes( strFile.c_str() ) );

	if ( request.getAttributes() != -1 )
		found = true;
	else
	{
		// rip off the last portion
		strExtra = stripLast( strFile );

		while( !strFile.empty() )
		{
			// anything there?
			request.setAttributes( GetFileAttributes( strFile.c_str() ) );

			if ( request.getAttributes() != -1 )
			{
				// found something; better not be a folder
				if( ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY ) == 0 )
					found = true;
				break;
			}

			// rip off the next portion
			strExtra = stripLast( strFile ) + strExtra;
		}
	}


	
	//
	// ���� 3
	//
	if ( found )
	{
		// strip any trailing SEPCHAR
		if ( strFile[strFile.size()-1] == SEPCHAR )
			request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
		else
			request.setFullPath( strFile );

		// see if we need to set the extra path info
		if ( !strExtra.empty() )
		{
			request.setPathInfo( strExtra );

			if ( urlToPath( strExtra ) )
				request.setPathTranslated( strExtra );
		}

		// if it's a folder, see if we can redirect to
		// one of the default docs or apps
		if ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY )
		{
			// check for existence of a default doc or app
			if ( !checkDefault( request, IDS_DEFAULTDOC, false ) )
				checkDefault( request, IDS_DEFAULTAPP, true );
		}
		else if ( request.getExecute() && !isSeverApp(request) )
		{
			request.addError( idHttpBadRequest );
		}
	}
	else
	{
		request.addError( idHttpNotFound );
	}

	
	return found;
}
