
/*************************************
ͨ���������������֪��

��������������ڡ����顱ְ��һ�£����԰��Ƶ�����ǰλ��

	request.setAttributes( GetFileAttributes( strFile.c_str() ) );

*/



bool HttpServerInfo::find ( HttpRequest & request, 
						    string & strFile )
{

	//
	// ���� 1������ url �õ� path������FileAttribute 
	//
	strFile = request.getUrl();// get url

	StringUtil::trimLeft( strFile, "/" );// remove leading indicators

	if ( ! urlToPath( strFile ) )// change from URL to local file system path
	{
		request.addError( idHttpBadRequest );
		return false;
	}

	request.setAttributes( GetFileAttributes( strFile.c_str() ) );



	//
	// ���� 2������ PathInfo 
	//
	string strExtra; // extra path info
	bool found = makeExtraPath(request, strFile, strExtra );
	
	if ( ! found )
	{
		request.addError( idHttpNotFound );
		return false;
	}
	
	if ( !strExtra.empty() )// see if we need to set the extra path info
	{
		request.setPathInfo( strExtra );

		if ( urlToPath( strExtra ) )
			request.setPathTranslated( strExtra );
	}



	//
	// ���� 3������ FullPath
	//

	// strip any trailing SEPCHAR
	if ( strFile[strFile.size()-1] == SEPCHAR )
		request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
	else
		request.setFullPath( strFile );


	//
	// ���� 4������Ҫ�� redirect���ض���
	//
	// if it's a folder, see if we can redirect to
	// one of the default docs or apps
	if ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY )
	{
		// check for existence of a default doc or app
		if ( !checkDefault( request, IDS_DEFAULTDOC, false ) )
			checkDefault( request, IDS_DEFAULTAPP, true );
	}
	else if ( request.getExecute() && !isSeverApp(request) )
	{
		request.addError( idHttpBadRequest );
	}

	
	return found;
}




bool HttpServerInfo::makeExtraPath ( HttpRequest & request, 
						    string & strFile, string & strExtra )
{

	// rip off the last portion
	strExtra = stripLast( strFile );

	while( !strFile.empty() )
	{
		// anything there?
		request.setAttributes( GetFileAttributes( strFile.c_str() ) );

		if ( request.getAttributes() != -1 )
		{
			// found something; better not be a folder
			if( ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY ) == 0 )
			{
				return true;
			}
		}

		// rip off the next portion
		strExtra = stripLast( strFile ) + strExtra;
	}

	return false;

}
