

bool CIMIClassicView::onKeyEvent(const CKeyEvent& key)
{
    unsigned changeMasks = 0;

    unsigned keycode = key.code;
    unsigned keyvalue = key.value;
    unsigned modifiers = key.modifiers;
    
    
    

    if (m_pHotkeyProfile && m_pHotkeyProfile->isModeSwitchKey(key)) 
    {
        sendMessage( �߼��¼�, key );
    }
    else if (m_pHotkeyProfile && m_pHotkeyProfile->isPunctSwitchKey(key))//On CTRL+.
    {
        sendMessage( �߼��¼�, key );
    }
    else if (m_pHotkeyProfile && m_pHotkeyProfile->isSymbolSwitchKey(key))//On SHIFT+SPACE
    {
        sendMessage( �߼��¼�, key );
    }
    
    
    else if (modifiers == IM_CTRL_MASK && keycode == IM_VK_LEFT)// move left  
    { 
        sendMessage( �߼��¼�, key );
    }
    else if (modifiers == IM_CTRL_MASK && keycode == IM_VK_RIGHT) // move right
    { 
        sendMessage( �߼��¼�, key );
    }
    else if ( ((modifiers == 0 && keycode == IM_VK_PAGE_UP) ||
                 (m_pHotkeyProfile && m_pHotkeyProfile->isPageUpKey (key))) &&
                !m_pIC->isEmpty() ) 
    {
        sendMessage( �߼��¼�, key );
    } 
    else if ( ((modifiers == 0 && keycode == IM_VK_PAGE_DOWN) ||
                 (m_pHotkeyProfile && m_pHotkeyProfile->isPageDownKey (key))) &&
                !m_pIC->isEmpty() ) 
    {
        sendMessage( �߼��¼�, key );
    }
    else if (m_pHotkeyProfile && m_pHotkeyProfile->isCandiDeleteKey(key, m_candiWindowSize) &&
             !m_pIC->isEmpty ()) 
    {
        sendMessage( �߼��¼�, key );
    }
    
    
    
    else if ((modifiers & (IM_CTRL_MASK | IM_ALT_MASK | IM_SUPER_MASK | IM_RELEASE_MASK)) == 0) 
    {
        if ((keyvalue >= '0' && keyvalue <= '9') &&
                   (m_candiWindowSize >= 10 || keyvalue < ('1' + m_candiWindowSize))) // try to make selection
        { 
            if (!m_pIC->isEmpty ()) 
            {
                sendMessage( �߼��¼�, key );
            }
            else
            {
                sendMessage( �߼��¼�, key );
            }
        }        
        else if (keyvalue == '.' && m_numeric_mode) 
        {
            sendMessage( �߼��¼�, key );
        }
        else
        {
            sendMessage( �߼��¼�, key );
        }        
    } 
    else 
    {
        sendMessage( �߼��¼�, key );
    } 

    return changeMasks & KEYEVENT_USED;
}


