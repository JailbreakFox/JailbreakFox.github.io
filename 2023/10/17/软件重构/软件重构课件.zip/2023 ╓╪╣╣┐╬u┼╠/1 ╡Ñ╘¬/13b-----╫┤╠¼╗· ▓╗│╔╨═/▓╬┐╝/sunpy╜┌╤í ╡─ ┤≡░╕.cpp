else if ((modifiers & (IM_CTRL_MASK | IM_ALT_MASK | IM_SUPER_MASK | IM_RELEASE_MASK)) == 0) 
{
	switch( _judgeCase(changeMasks, keyvalue) )
	{
	case CASE_MAKE_SELECT:
		
		changeMasks |= KEYEVENT_USED;
		unsigned sel = (keyvalue == '0'? 9: keyvalue-'1');
		_makeSelection (sel, changeMasks);
		m_pHotkeyProfile->rememberLastKey(key);
		break;
		
	case CASE_NUMMODE_BEGIN:
		
		m_numeric_mode = true;
		m_pHotkeyProfile->rememberLastKey(key);
		break;
		
	case CASE_NUMMODE_END:
		
		m_numeric_mode = false;
		m_pHotkeyProfile->rememberLastKey(key);
		break;
		
	case CASE_COMMON_INPUT:
		
		m_numeric_mode = false;
		_eventProcessHelper(changeMasks,keycode, keyvalue, modifiers);
		break;
		
	default:
		break;							
	}	
}   	


int CIMIClassicView::_judgeCase (	unsigned changeMasks,unsigned keyvalue, )
{
    if ((keyvalue >= '0' && keyvalue <= '9') &&
        (m_candiWindowSize >= 10 || keyvalue < ('1' + m_candiWindowSize))) 
    { 
        if (!m_pIC->isEmpty ()) 
            return CASE_MAKE_SELECT;             
        else
            return CASE_NUMMODE_BEGIN;        
     } 
    else if (keyvalue == '.' && m_numeric_mode) 
        return CASE_NUMMODE_END;
    else 
        return CASE_COMMON_INPUT;
}
