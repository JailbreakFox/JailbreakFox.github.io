
//##ModelId=424BB6440076
bool HttpServerInfo::find ( HttpRequest & request, 
						    string & strFile )
{
	bool found = false;

	// get url
	strFile = request.getUrl();

	// remove leading indicators
	StringUtil::trimLeft( strFile, "/" );


	// change from URL to local file system path
	if ( urlToPath( strFile ) )
	{
		string strExtra; // extra path info

		request.setAttributes( GetFileAttributes( strFile.c_str() ) );

		if ( request.getAttributes() != -1 )
			found = true;
		else
		{
			// rip off the last portion
			strExtra = stripLast( strFile );

			while( !strFile.empty() )
			{
				// anything there?
				request.setAttributes( GetFileAttributes( strFile.c_str() ) );

				if ( request.getAttributes() != -1 )
				{
					// found something; better not be a folder
					if( ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY ) == 0 )
						found = true;
					break;
				}

				// rip off the next portion
				strExtra = stripLast( strFile ) + strExtra;
			}
		}
	

		
		// #DGH
		// come back to later
		// this code exists in above if statement

		
		if ( found )
		{
			// strip any trailing SEPCHAR
			if ( strFile[strFile.size()-1] == SEPCHAR )
				request.setFullPath( StringUtil::left( strFile, strFile.size()-1 ) );
			else
				request.setFullPath( strFile );

			// see if we need to set the extra path info
			if ( !strExtra.empty() )
			{
				request.setPathInfo( strExtra );

				if ( urlToPath( strExtra ) )
					request.setPathTranslated( strExtra );
			}

			// if it's a folder, see if we can redirect to
			// one of the default docs or apps
			if ( request.getAttributes() & FILE_ATTRIBUTE_DIRECTORY )
			{
				// check for existence of a default doc or app
				if ( !checkDefault( request, IDS_DEFAULTDOC, false ) )
					checkDefault( request, IDS_DEFAULTAPP, true );
			}
			else if ( request.getExecute() && !isSeverApp(request) )
			{
				request.addError( idHttpBadRequest );
			}
		}
		else
		{
			request.addError( idHttpNotFound );
		}
	}
	else
	{
		request.addError( idHttpBadRequest );
	}

	
	return found;
}
