#include "traffic.h"
#include "ledgroup.h"
#include "time.h"



/***************************************************************
*
* ����ӿں�������
*
***************************************************************/

//ÿ��sate�Ĵ����Ǽܣ����ص�����
void trafficControlStateProcess(
	int xroadStateDuration, 
	int yroadStateDuration, 
	LightControlFunc lightFunc, 
	EndJudgeFunc judgeFunc)
{
	timerInit(xroadStateDuration,yroadStateDuration);
	while(1)
	{	 
		if(receiveSecondEvent())
		{
			(*lightFunc)(); /////// call back
			xroadLedDisplay(getVirtualTimer1());
			yroadLedDisplay(getVirtualTimer2());
		}
		if((*judgeFunc)()) /////// call back
		{
			break;
		}
	}
}

