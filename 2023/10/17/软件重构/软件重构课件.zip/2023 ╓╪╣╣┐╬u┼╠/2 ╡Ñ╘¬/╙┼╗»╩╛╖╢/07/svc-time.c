#include "drv-time89c51.h"
#include "svc-time.h"



/***************************************************************
*
* ģ����˽�г���
*
***************************************************************/
#define COUNT_FOR_1SECOND     20

//����ʱ�� 0 �׳�event��
//�ټ�һ������NO_VIRTUAL_TIMER�൱��timerֹͣ
#define NO_VIRTUAL_TIMER  -1




/***************************************************************
*
* ģ����˽�б�������
*
***************************************************************/
static struct TimeManager
{
	int  clickCount;
	bool secondEvent;
	int  virtualTimer1;
	int  virtualTimer2;
	bool virtualTimer1Event;
	bool virtualTimer2Event;
} tm = {
	0,
	false,
	NO_VIRTUAL_TIMER,
	NO_VIRTUAL_TIMER,
	false,
	false
};


/***************************************************************
*
* ģ����˽��help��������
*
***************************************************************/
static void interruptCallback()
{
	tm.clickCount++;	
	if( tm.clickCount == COUNT_FOR_1SECOND )
	{
		//second event
		tm.clickCount = 0;
		tm.secondEvent = true;
		
		//timer 1 event
		if(tm.virtualTimer1 != NO_VIRTUAL_TIMER)
			tm.virtualTimer1--;
		if(tm.virtualTimer1 == 0)
			tm.virtualTimer1Event = true;

		//timer 2 event
		if(tm.virtualTimer2 != NO_VIRTUAL_TIMER)
			tm.virtualTimer2--;
		if(tm.virtualTimer2 == 0)
			tm.virtualTimer2Event = true;
	}
}


/***************************************************************
*
* ����ӿں�������
*
***************************************************************/

bool timerInit(int vt1, int vt2)
{
	if(vt1<=0 || vt2<=0) //ֻ�������������򱨴�
		return false; 

	tm.clickCount = 0;
	tm.secondEvent = false;
	tm.virtualTimer1 = vt1;
	tm.virtualTimer2 = vt2;
	tm.virtualTimer1Event = false;
	tm.virtualTimer2Event = false;
	
	time89c51InterruptInit();
	set50msInterruptCallback(interruptCallback);	
	
	return true;
}

bool receiveSecondEvent()
{
	if( true == tm.secondEvent )
	{
		tm.secondEvent = false; //receive���¼������ѵ�
		return true;
	}
	return false;
}

int getVirtualTimer1()
{
	return tm.virtualTimer1;
}

int getVirtualTimer2()
{
	return tm.virtualTimer2;
}

bool receiveVirtualTimer1Event()
{
	if( true == tm.virtualTimer1Event )
	{
		tm.virtualTimer1Event = false; //receive���¼������ѵ�
		return true;
	}
	return false;
}

bool receiveVirtualTimer2Event()
{
	if( true == tm.virtualTimer2Event )
	{
		tm.virtualTimer2Event = false; //receive���¼������ѵ�
		return true;
	}
	return false;
}

// ǿ�Ƹ��� timer1 ��ֵ��timer2 ��ֵҲ��Ӧ�Զ��䶯
void setVirtualTimer1(int vt1)
{
	int tmp = tm.virtualTimer2 - tm.virtualTimer1;
	
	tm.virtualTimer1 = vt1;
	tm.virtualTimer2 = vt1+tmp;
}

