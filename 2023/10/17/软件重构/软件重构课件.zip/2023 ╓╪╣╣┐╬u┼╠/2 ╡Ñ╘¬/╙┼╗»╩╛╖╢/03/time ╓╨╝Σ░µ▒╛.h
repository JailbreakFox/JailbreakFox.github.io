#include <reg51.h>

bool receiveSecondEvent();
