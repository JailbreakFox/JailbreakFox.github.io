#include <reg51.h>


void set50msInterruptCallback(void (*cb)(void));

void time89c51InterruptInit(void)

