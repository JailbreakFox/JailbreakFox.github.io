#include "light.h"


void setAll(Lights *ls)
{
	ls->ASG=1;
	ls->ALG=1;
	ls->ASR=1;
	ls->ALR=1;
	ls->ASY=1;
	ls->ALY=1;
	ls->BLG=1;
	ls->BSG=1;
	ls->BLR=1;
	ls->BSR=1;
	ls->BLY=1;
	ls->BSY=1;
}


void clearAll(Lights *ls)
{
	ls->ASG=0;
	ls->ALG=0;
	ls->ASR=0;
	ls->ALR=0;
	ls->ASY=0;
	ls->ALY=0;
	ls->BLG=0;
	ls->BSG=0;
	ls->BLR=0;
	ls->BSR=0;
	ls->BLY=0;
	ls->BSY=0;
}


void roadAaaGreen(Lights *ls)
{
	clearAll(ls);
	ls->ASG=1; //A·ֱ�з���
	ls->ALR=1;
	ls->BLR=1;
	ls->BSR=1;		
}

void roadAaaPreRed(Lights *ls)
{
	clearAll(ls);
	ls->BLR=1;
	ls->BSR=1;
}

void roadAaaRed(Lights *ls)
{
	clearAll(ls);
	ls->ASR=1;
	ls->ALG=1;  //A·��ת����
	ls->BLR=1;
	ls->BSR=1;
}

void roadAaaPostRed(Lights *ls)
{
	clearAll(ls);
	ls->ASR=1;
	ls->BLR=1;
}

void roadBbbGreen(Lights *ls)
{
	clearAll(ls);
	ls->ASR=1;
	ls->ALR=1;
	ls->BSG=1; //B·ֱ�з���
	ls->BLR=1;
}

void roadBbbPreRed(Lights *ls)
{
	clearAll(ls);
	ls->ALR=1;
	ls->ASR=1;
}

void roadBbbRed(Lights *ls)
{
	clearAll(ls);
	ls->ASR=1;
	ls->ALR=1;
	ls->BSR=1;
	ls->BLG=1; //B·��ת����
}

void roadBbbPostRed(Lights *ls)
{
	/* ���֣�ԭ�ȵĴ�����bug 
	BLR=0;
	BLG=0;
	BSR=0;
	BSG=0;
	BSY=0;
	ASG=0;
	ALG=0;
	ALR=0;
	ALY=0;
	ASY=0;
	*/		
	
	clearAll(ls);
	// ĳ��� = 1;
	// ĳ��� = 1;
	
}


void roadAaaBothGreen(Lights *ls)
{
	clearAll(ls);
	ls->ASG=1;//A·ֱ�з���
	ls->ALG=1;//A·��ת����
	ls->BSR=1;
	ls->BLR=1;
}

void roadBbbBothGreen(Lights *ls)
{
	clearAll(ls);
	ls->ASR=1;
	ls->ALR=1;
	ls->BSG=1;//B·ֱ�з���
	ls->BLG=1;//B·��ת����
}
	
void flashing(Lights *ls, int step)
{
	if(step == 3)
	{
		ls->ASY=~ASY;
		ls->ALR=~ALR;
	}
	else if(step == 5)
	{
		ls->ALY=~ALY;
		ls->BSR=~BSR;	}
	else if(step == 7)
	{
		ls->BSY=~BSY;
		ls->BLR=~BLR;	}
	else if(step == 9)
	{
		ls->BLY=~BLY;
		ls->ASR=~ASR;		
	}
}	


void allRed(Lights *ls)
{
	clearAll(ls);
	ls->ALR=1;
	ls->ASR=1;               
	ls->BLR=1;
	ls->BSR=1;
}



