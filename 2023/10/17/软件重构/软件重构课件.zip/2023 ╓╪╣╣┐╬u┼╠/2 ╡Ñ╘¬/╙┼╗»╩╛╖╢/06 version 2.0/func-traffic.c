#include "traffic.h"
#include "ledgroup.h"
#include "time.h"


/***************************************************************
*
* ģ����˽��: ״̬�����ص�const��var
*
***************************************************************/
#define MIN_STATE_NO      1
#define MAX_STATE_NO      8
#define CAN_CUT_STATE_NO  1

static int stateNo = 0;



/***************************************************************
*
* ģ����˽��: ͨ��������ص�const��var
*
***************************************************************/
//ֱ��ͨ�к���תͨ��������˸̬���м���
#define FLASHING_HOWMANY_SECONDS  10

//
//xroadֱ��--��˸--xroad��ת--��˸--yroadֱ��--��˸--yroad��ת--��˸
//���˸�״̬����������
//
//���԰���define������֧·ֱ�к���תһͬ����
//
static int D[8] = {  //Durations
	60, FLASHING_HOWMANY_SECONDS,   //��·ֱ�У�ʱ�䳤
	10, FLASHING_HOWMANY_SECONDS,   //��·��ת
	30, FLASHING_HOWMANY_SECONDS,   //֧·ֱ�У�ʱ���
	10, FLASHING_HOWMANY_SECONDS};  //֧·��ת


/***************************************************************
*
* ģ����˽��: ��������
*
***************************************************************/
static struct stateDefineArray
{
	int stNo;
	char* stName;
	int xroadStateDuration;
	int yroadStateDuration;
	LightControlFunc lightFunc;
	EndJudgeFunc judgeFunc;
} stateDefArr[9] =  {
	{0, "test",            5,                  5,                  allRed,        receiveVirtualTimer1Event},
	{1, "xroad green",     D[0],               D[0]+D[1]+D[2]+D[3],xroadGreen,    receiveVirtualTimer1Event},
	{2, "xroad green tail",D[1],               D[1]+D[2]+D[3],     xroadGreenTail,receiveVirtualTimer1Event},
	{3, "xroad left",      D[2],               D[2]+D[3],          xroadLeft,     receiveVirtualTimer1Event},
	{4, "xroad left",      D[3],               D[3],               xroadLeftRail, receiveVirtualTimer1Event},
	{5, "yroad green",     D[4]+D[5]+D[6]+D[7],D[4],               yroadGreen,    receiveVirtualTimer2Event},
	{6, "yroad green tail",D[5]+D[6]+D[7],     D[5],               yroadGreenTail,receiveVirtualTimer2Event},
	{7, "yroad left",      D[6]+D[7],          D[6],               yroadLeft,     receiveVirtualTimer2Event},
	{8, "yroad left tail", D[7],               D[7],               yroadLeftRail, receiveVirtualTimer2Event}	
};


/***************************************************************
*
* ģ����˽��help��������
*
***************************************************************/
static void trafficGetStateNo()
{
	return stateNo;
}

//ÿ��state�Ĵ����Ǽܣ����ص�����
static void stateHelper(
	int stNo,
	char* stName,
	int xroadStateDuration, 
	int yroadStateDuration, 
	LightControlFunc lightFunc, 
	EndJudgeFunc judgeFunc)
{
	stateNo = stNo;
	timerInit(xroadStateDuration,yroadStateDuration);
	while(1)
	{	 
		if(receiveSecondEvent())
		{
			(*lightFunc)(); /////// call back
			xroadLedDisplay(getVirtualTimer1());
			yroadLedDisplay(getVirtualTimer2());
		}
		if((*judgeFunc)()) /////// call back
		{
			break;
		}
	}
}


/***************************************************************
*
* ����ӿں�������
*
***************************************************************/
void trafficControlStateProcess()
{
	void stateHelper(stateNo,
		stateDefArr[stateNo].stName,
		stateDefArr[stateNo].xroadStateDuration, 
		stateDefArr[stateNo].yroadStateDuration, 
		stateDefArr[stateNo].lightFunc, 
		stateDefArr[stateNo].judgeFunc );
}

void trafficGotoNextState()
{
	stateNo++;
	if (stateNo > MAX_STATE_NO)
		stateNo = MIN_STATE_NO;
}

void xroadGreenBecomeShort( )
{
	if( trafficGetStateNo() == CAN_CUT_STATE_NO )
		if( getVirtualTimer1() > 5 )
			setVirtualTimer1(5);
}


