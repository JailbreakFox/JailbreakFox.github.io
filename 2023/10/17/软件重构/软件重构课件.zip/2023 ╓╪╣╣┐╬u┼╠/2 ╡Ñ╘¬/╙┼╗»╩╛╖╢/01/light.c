#include "light.h"



/***************************************************************
*
* ģ����˽�б�������
*
***************************************************************/
static struct LightPorts{
	sbit   ALG;  //A·��ת�̵�
	sbit   ALR;  //A·��ת���
	sbit   ALY;  //A·��ת�Ƶ�
	sbit   ASG;  //A·ֱ���̵�
	sbit   ASR;  //A·ֱ�к��
	sbit   ASY;  //A·ֱ�лƵ�
	sbit   BLG;  //B·��ת�̵�
	sbit   BLR;  //B·��ת���
	sbit   BLY;  //B·��ת�Ƶ�
	sbit   BSG;  //B·ֱ���̵�
	sbit   BSR;  //B·ֱ�к��
	sbit   BSY;  //B·ֱ�лƵ�
} lightPorts = {
	P1^2,
	P1^0,
	P1^1,
	P1^5,
	P1^3,
	P1^4,
	P2^0,
	P1^6,
	P1^7,
	P2^3,
	P2^1,
	P2^2   };



/***************************************************************
*
* ����ӿں�������
*
***************************************************************/	
void setAll( )
{
	lightPorts.ASG=1;
	lightPorts.ALG=1;
	lightPorts.ASR=1;
	lightPorts.ALR=1;
	lightPorts.ASY=1;
	lightPorts.ALY=1;
	lightPorts.BLG=1;
	lightPorts.BSG=1;
	lightPorts.BLR=1;
	lightPorts.BSR=1;
	lightPorts.BLY=1;
	lightPorts.BSY=1;
}

void clearAll( )
{
	lightPorts.ASG=0;
	lightPorts.ALG=0;
	lightPorts.ASR=0;
	lightPorts.ALR=0;
	lightPorts.ASY=0;
	lightPorts.ALY=0;
	lightPorts.BLG=0;
	lightPorts.BSG=0;
	lightPorts.BLR=0;
	lightPorts.BSR=0;
	lightPorts.BLY=0;
	lightPorts.BSY=0;
}

void xroadGreen( )
{
	clearAll();
	lightPorts.ASG=1; //A·ֱ�з���
	lightPorts.ALR=1;
	lightPorts.BLR=1;
	lightPorts.BSR=1;		
}

void xroadGreenTail( )
{
	clearAll();
	lightPorts.BLR=1;
	lightPorts.BSR=1;
}

void xroadLeft( )
{
	clearAll();
	lightPorts.ASR=1;
	lightPorts.ALG=1;  //A·��ת����
	lightPorts.BLR=1;
	lightPorts.BSR=1;
}

void xroadLeftRail( )
{
	clearAll();
	lightPorts.ASR=1;
	lightPorts.BLR=1;
}

void yroadGreen( )
{
	clearAll();
	lightPorts.ASR=1;
	lightPorts.ALR=1;
	lightPorts.BSG=1; //B·ֱ�з���
	lightPorts.BLR=1;
}

void yroadGreenTail( )
{
	clearAll();
	lightPorts.ALR=1;
	lightPorts.ASR=1;
}

void yroadLeft( )
{
	clearAll();
	lightPorts.ASR=1;
	lightPorts.ALR=1;
	lightPorts.BSR=1;
	lightPorts.BLG=1; //B·��ת����
}

void yroadLeftRail( )
{
	/* ���֣�ԭ�ȵĴ�����bug 
	BLR=0;
	BLG=0;
	BSR=0;
	BSG=0;
	BSY=0;
	ASG=0;
	ALG=0;
	ALR=0;
	ALY=0;
	ASY=0;
	*/		
	
	clearAll();
	// ĳ��� = 1;
	// ĳ��� = 1;
}
	
void flashing(int step)
{
	if(step == 3)
	{
		lightPorts.ASY=~ASY;
		lightPorts.ALR=~ALR;
	}
	else if(step == 5)
	{
		lightPorts.ALY=~ALY;
		lightPorts.BSR=~BSR;	}
	else if(step == 7)
	{
		lightPorts.BSY=~BSY;
		lightPorts.BLR=~BLR;	}
	else if(step == 9)
	{
		lightPorts.BLY=~BLY;
		lightPorts.ASR=~ASR;		
	}
}	

void allRed( )
{
	clearAll();
	lightPorts.ALR=1;
	lightPorts.ASR=1;               
	lightPorts.BLR=1;
	lightPorts.BSR=1;
}

