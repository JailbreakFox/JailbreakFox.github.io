#include <reg51.h>



void setAll( );
void clearAll( );

void allRed( );
void xroadGreen( );
void xroadGreenTail( );
void xroadLeft( );
void xroadLeftRail( );
void yroadGreen( );
void yroadGreenTail( );
void yroadLeft( );
void yroadLeftRail( );

void flashing(int step);
