

void  delay(int z);
